<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * OsceSkills2 Controller
 *
 * @property \App\Model\Table\OsceSkills2Table $OsceSkills2
 */
class OsceSkills2Controller extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Nursings']
        ];
        $osceSkills2 = $this->paginate($this->OsceSkills2);

        $this->set(compact('osceSkills2'));
        $this->set('_serialize', ['osceSkills2']);
    }

    /**
     * View method
     *
     * @param string|null $id Osce Skills2 id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $osceSkills2 = $this->OsceSkills2->get($id, [
            'contain' => ['Nursings']
        ]);

        $this->set('osceSkills2', $osceSkills2);
        $this->set('_serialize', ['osceSkills2']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $osceSkills2 = $this->OsceSkills2->newEntity();
        if ($this->request->is('post')) {
            $osceSkills2 = $this->OsceSkills2->patchEntity($osceSkills2, $this->request->data);
            if ($this->OsceSkills2->save($osceSkills2)) {
                $this->Flash->success(__('The osce skills2 has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The osce skills2 could not be saved. Please, try again.'));
            }
        }
        $nursings = $this->OsceSkills2->Nursings->find('list', ['limit' => 200]);
        $this->set(compact('osceSkills2', 'nursings'));
        $this->set('_serialize', ['osceSkills2']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Osce Skills2 id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $osceSkills2 = $this->OsceSkills2->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $osceSkills2 = $this->OsceSkills2->patchEntity($osceSkills2, $this->request->data);
            if ($this->OsceSkills2->save($osceSkills2)) {
                $this->Flash->success(__('The osce skills2 has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The osce skills2 could not be saved. Please, try again.'));
            }
        }
        $nursings = $this->OsceSkills2->Nursings->find('list', ['limit' => 200]);
        $this->set(compact('osceSkills2', 'nursings'));
        $this->set('_serialize', ['osceSkills2']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Osce Skills2 id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $osceSkills2 = $this->OsceSkills2->get($id);
        if ($this->OsceSkills2->delete($osceSkills2)) {
            $this->Flash->success(__('The osce skills2 has been deleted.'));
        } else {
            $this->Flash->error(__('The osce skills2 could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }


    public function Oskills2()
    {
        $arrival = $this->OsceSkills2->find('all');


        $wo = $arrival->all();
        $this->set('wo',$wo);
        $this->set('pe',$this->Auth->User("fname"));
        $this->set('_serialize', ['osceSkills']);
    
 
    }
}
