<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * OsceSkills4 Controller
 *
 * @property \App\Model\Table\OsceSkills4Table $OsceSkills4
 */
class OsceSkills4Controller extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Nursings']
        ];
        $osceSkills4 = $this->paginate($this->OsceSkills4);

        $this->set(compact('osceSkills4'));
        $this->set('_serialize', ['osceSkills4']);
    }

    /**
     * View method
     *
     * @param string|null $id Osce Skills4 id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $osceSkills4 = $this->OsceSkills4->get($id, [
            'contain' => ['Nursings']
        ]);

        $this->set('osceSkills4', $osceSkills4);
        $this->set('_serialize', ['osceSkills4']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $osceSkills4 = $this->OsceSkills4->newEntity();
        if ($this->request->is('post')) {
            $osceSkills4 = $this->OsceSkills4->patchEntity($osceSkills4, $this->request->data);
            if ($this->OsceSkills4->save($osceSkills4)) {
                $this->Flash->success(__('The osce skills4 has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The osce skills4 could not be saved. Please, try again.'));
            }
        }
        $nursings = $this->OsceSkills4->Nursings->find('list', ['limit' => 200]);
        $this->set(compact('osceSkills4', 'nursings'));
        $this->set('_serialize', ['osceSkills4']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Osce Skills4 id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $osceSkills4 = $this->OsceSkills4->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $osceSkills4 = $this->OsceSkills4->patchEntity($osceSkills4, $this->request->data);
            if ($this->OsceSkills4->save($osceSkills4)) {
                $this->Flash->success(__('The osce skills4 has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The osce skills4 could not be saved. Please, try again.'));
            }
        }
        $nursings = $this->OsceSkills4->Nursings->find('list', ['limit' => 200]);
        $this->set(compact('osceSkills4', 'nursings'));
        $this->set('_serialize', ['osceSkills4']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Osce Skills4 id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $osceSkills4 = $this->OsceSkills4->get($id);
        if ($this->OsceSkills4->delete($osceSkills4)) {
            $this->Flash->success(__('The osce skills4 has been deleted.'));
        } else {
            $this->Flash->error(__('The osce skills4 could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }


    public function Oskills4()
    {
        $arrival = $this->OsceSkills4->find('all');


        $wo = $arrival->all();
        $this->set('wo',$wo);
        $this->set('pe',$this->Auth->User("fname"));
        $this->set('_serialize', ['osceSkills']);
    
 
    }
}
