<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * OsceSkills3 Controller
 *
 * @property \App\Model\Table\OsceSkills3Table $OsceSkills3
 */
class OsceSkills3Controller extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Nursings']
        ];
        $osceSkills3 = $this->paginate($this->OsceSkills3);

        $this->set(compact('osceSkills3'));
        $this->set('_serialize', ['osceSkills3']);
    }

    /**
     * View method
     *
     * @param string|null $id Osce Skills3 id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $osceSkills3 = $this->OsceSkills3->get($id, [
            'contain' => ['Nursings']
        ]);

        $this->set('osceSkills3', $osceSkills3);
        $this->set('_serialize', ['osceSkills3']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $osceSkills3 = $this->OsceSkills3->newEntity();
        if ($this->request->is('post')) {
            $osceSkills3 = $this->OsceSkills3->patchEntity($osceSkills3, $this->request->data);
            if ($this->OsceSkills3->save($osceSkills3)) {
                $this->Flash->success(__('The osce skills3 has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The osce skills3 could not be saved. Please, try again.'));
            }
        }
        $nursings = $this->OsceSkills3->Nursings->find('list', ['limit' => 200]);
        $this->set(compact('osceSkills3', 'nursings'));
        $this->set('_serialize', ['osceSkills3']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Osce Skills3 id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $osceSkills3 = $this->OsceSkills3->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $osceSkills3 = $this->OsceSkills3->patchEntity($osceSkills3, $this->request->data);
            if ($this->OsceSkills3->save($osceSkills3)) {
                $this->Flash->success(__('The osce skills3 has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The osce skills3 could not be saved. Please, try again.'));
            }
        }
        $nursings = $this->OsceSkills3->Nursings->find('list', ['limit' => 200]);
        $this->set(compact('osceSkills3', 'nursings'));
        $this->set('_serialize', ['osceSkills3']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Osce Skills3 id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $osceSkills3 = $this->OsceSkills3->get($id);
        if ($this->OsceSkills3->delete($osceSkills3)) {
            $this->Flash->success(__('The osce skills3 has been deleted.'));
        } else {
            $this->Flash->error(__('The osce skills3 could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }


    public function Oskills3()
    {
        $arrival = $this->OsceSkills3->find('all');


        $wo = $arrival->all();
        $this->set('wo',$wo);
        $this->set('pe',$this->Auth->User("fname"));
        $this->set('_serialize', ['osceSkills']);
    
 
    }
}
