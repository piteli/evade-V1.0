<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * OsceSkills5 Controller
 *
 * @property \App\Model\Table\OsceSkills5Table $OsceSkills5
 */
class OsceSkills5Controller extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Nursings']
        ];
        $osceSkills5 = $this->paginate($this->OsceSkills5);

        $this->set(compact('osceSkills5'));
        $this->set('_serialize', ['osceSkills5']);
    }

    /**
     * View method
     *
     * @param string|null $id Osce Skills5 id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $osceSkills5 = $this->OsceSkills5->get($id, [
            'contain' => ['Nursings']
        ]);

        $this->set('osceSkills5', $osceSkills5);
        $this->set('_serialize', ['osceSkills5']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $osceSkills5 = $this->OsceSkills5->newEntity();
        if ($this->request->is('post')) {
            $osceSkills5 = $this->OsceSkills5->patchEntity($osceSkills5, $this->request->data);
            if ($this->OsceSkills5->save($osceSkills5)) {
                $this->Flash->success(__('The osce skills5 has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The osce skills5 could not be saved. Please, try again.'));
            }
        }
        $nursings = $this->OsceSkills5->Nursings->find('list', ['limit' => 200]);
        $this->set(compact('osceSkills5', 'nursings'));
        $this->set('_serialize', ['osceSkills5']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Osce Skills5 id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $osceSkills5 = $this->OsceSkills5->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $osceSkills5 = $this->OsceSkills5->patchEntity($osceSkills5, $this->request->data);
            if ($this->OsceSkills5->save($osceSkills5)) {
                $this->Flash->success(__('The osce skills5 has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The osce skills5 could not be saved. Please, try again.'));
            }
        }
        $nursings = $this->OsceSkills5->Nursings->find('list', ['limit' => 200]);
        $this->set(compact('osceSkills5', 'nursings'));
        $this->set('_serialize', ['osceSkills5']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Osce Skills5 id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $osceSkills5 = $this->OsceSkills5->get($id);
        if ($this->OsceSkills5->delete($osceSkills5)) {
            $this->Flash->success(__('The osce skills5 has been deleted.'));
        } else {
            $this->Flash->error(__('The osce skills5 could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
